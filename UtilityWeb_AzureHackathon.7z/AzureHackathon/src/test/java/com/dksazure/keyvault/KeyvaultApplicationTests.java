package com.dksazure.keyvault;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeyvaultApplicationTests {

	@Test
	void contextLoads() {
	}

}
