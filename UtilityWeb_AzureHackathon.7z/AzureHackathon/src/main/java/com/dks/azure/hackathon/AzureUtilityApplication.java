package com.dks.azure.hackathon;

import java.io.File;
import java.io.FileWriter;

import org.bson.Document;
import org.json.JSONObject;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@SpringBootApplication
@RestController
public class AzureUtilityApplication {

	@GetMapping("/")
	public String get() {
		return "Welcome";
	}
	
	@GetMapping("/downloadDBCollections")
	public String getDownloadCollection(@RequestParam(value = "collection") String collection) {
		
		/** Replace connection string from the Azure Cosmos DB Portal */
		String uri = "mongodb://@cosmos-lyfchat-mainuat.documents.azure.com:10255/admin?ssl=true&replicaSet=globaldb";

		MongoClient mongoClient = null;

		try {
			mongoClient = MongoClients.create(uri);
			// Get database
			MongoDatabase database = mongoClient.getDatabase("admin");

			// Retrieving the documents for POSTS
			MongoCollection<Document> table = database.getCollection(collection);

			for (Document doc : table.find()) {
				try {
					JSONObject jObject = new JSONObject(doc.toJson()); // json
					Object p1 = jObject.get("_id"); 
					System.out.println("TEST " + p1);
					JSONObject jObj = new JSONObject(p1.toString());
					System.out.println(jObj);
					Object projectname = jObj.get("$oid");

					File dir = new File("D://rawfile//userprofiles//test");
					if (!dir.exists()) {
						dir.mkdir();
					}

					System.out.println("Name:" + projectname);
					String fileName = projectname + ".txt";
					File tagFile = new File(dir, fileName);
					
					if (tagFile.exists()){
						tagFile.delete();
					 }  
					
					if (!tagFile.exists()) {

						FileWriter writer = new FileWriter(tagFile);
						writer.write(doc.toJson());
						writer.close();

						tagFile.createNewFile();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				System.out.println("Completed successfully");
			}
			
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			return "failure";
		} finally {
			if (mongoClient != null) {
				mongoClient.close();
			}
		}
		
	}

	public void run(String... varl) throws Exception {
	}
	public static void main(String[] args) {
		SpringApplication.run(AzureUtilityApplication.class, args);
	}

}
