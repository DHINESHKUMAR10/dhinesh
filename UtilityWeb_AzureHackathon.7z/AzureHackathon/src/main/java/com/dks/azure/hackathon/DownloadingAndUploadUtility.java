package com.dks.azure.hackathon;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;

@RestController
public class DownloadingAndUploadUtility {

	String keyVaultName = System.getenv("KEY_VAULT_NAME");
	String keyVaultUri = "https://" + keyVaultName + ".vault.azure.net";

	SecretClient secretClient = new SecretClientBuilder().vaultUrl(keyVaultUri)
			.credential(new DefaultAzureCredentialBuilder().build()).buildClient();

	@GetMapping("createSecret")
	public String createSecret(@RequestParam(value = "key") String Key, @RequestParam(value = "value") String value) {

		String response = null;
		return response;
	}
}
